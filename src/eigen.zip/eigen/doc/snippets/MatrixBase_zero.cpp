cout << Matrix2d::Zero() << endl;
cout << RowVector4i::Zero() << endl;
